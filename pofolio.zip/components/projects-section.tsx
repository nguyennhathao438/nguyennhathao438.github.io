import { Github, ExternalLink } from 'lucide-react'

const projects = [
  {
    title: 'Distributed Task Queue',
    description: 'A high-performance, distributed task queue built with Go and Redis. Supports millions of tasks per second with automatic retry logic and dead-letter handling.',
    technologies: ['Go', 'Redis', 'Protocol Buffers', 'PostgreSQL'],
    links: {
      github: '#',
      live: '#',
    },
  },
  {
    title: 'AI Content Generator',
    description: 'Multi-modal content generation platform leveraging LLMs and fine-tuned models. Built with Python, provides API-first architecture with rate limiting and caching.',
    technologies: ['Python', 'FastAPI', 'LLMs', 'Kubernetes'],
    links: {
      github: '#',
      live: '#',
    },
  },
  {
    title: 'Real-time Analytics Engine',
    description: 'Stream processing platform for real-time analytics. Handles 100k+ events per second with sub-second latency using event sourcing and CQRS patterns.',
    technologies: ['Node.js', 'Kafka', 'ClickHouse', 'React'],
    links: {
      github: '#',
      live: '#',
    },
  },
  {
    title: 'API Gateway & Service Mesh',
    description: 'Production-grade API gateway with service mesh capabilities. Features include rate limiting, authentication, request routing, and circuit breaking.',
    technologies: ['Go', 'Envoy', 'gRPC', 'Prometheus'],
    links: {
      github: '#',
      live: '#',
    },
  },
]

export function ProjectsSection() {
  return (
    <section
      id="projects"
      className="border-b border-border bg-background px-4 py-20 sm:px-6 lg:px-8"
    >
      <div className="mx-auto max-w-4xl">
        <div className="animate-fade-in-up space-y-12">
          <div>
            <h2 className="text-4xl font-bold text-foreground sm:text-5xl">
              Featured Projects
            </h2>
            <div className="mt-2 h-1 w-24 bg-gradient-to-r from-primary to-accent rounded" />
          </div>

          <div className="grid gap-8 md:grid-cols-2">
            {projects.map((project) => (
              <div
                key={project.title}
                className="flex flex-col rounded-lg border border-border bg-secondary/50 p-6 smooth-transition hover:border-accent hover:shadow-lg dark:bg-primary/5 dark:hover:shadow-accent/10"
              >
                <h3 className="text-xl font-semibold text-foreground">
                  {project.title}
                </h3>
                <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                  {project.description}
                </p>

                <div className="mt-4 flex flex-wrap gap-2">
                  {project.technologies.map((tech) => (
                    <span
                      key={tech}
                      className="rounded-full bg-accent/10 px-2.5 py-1 text-xs font-medium text-accent"
                    >
                      {tech}
                    </span>
                  ))}
                </div>

                <div className="mt-auto flex gap-4 pt-4">
                  <a
                    href={project.links.github}
                    className="inline-flex items-center gap-2 text-sm font-medium text-foreground smooth-transition hover:text-accent"
                  >
                    <Github className="h-4 w-4" />
                    Code
                  </a>
                  <a
                    href={project.links.live}
                    className="inline-flex items-center gap-2 text-sm font-medium text-foreground smooth-transition hover:text-accent"
                  >
                    <ExternalLink className="h-4 w-4" />
                    Demo
                  </a>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
