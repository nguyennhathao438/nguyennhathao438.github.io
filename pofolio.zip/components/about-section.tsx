export function AboutSection() {
  return (
    <section
      id="about"
      className="border-b border-border bg-background px-4 py-20 sm:px-6 lg:px-8"
    >
      <div className="mx-auto max-w-4xl">
        <div className="animate-fade-in-up space-y-12">
          <div>
            <h2 className="text-4xl font-bold text-foreground sm:text-5xl">
              About Me
            </h2>
            <div className="mt-2 h-1 w-24 bg-gradient-to-r from-primary to-accent rounded" />
          </div>

          <div className="grid gap-12 md:grid-cols-2">
            <div className="space-y-4">
              <p className="text-lg leading-relaxed text-muted-foreground">
                I'm a passionate backend engineer with over 5 years of experience building scalable, 
                high-performance systems. My expertise spans across distributed systems, cloud 
                infrastructure, and modern DevOps practices.
              </p>
              <p className="text-lg leading-relaxed text-muted-foreground">
                Beyond traditional backend work, I'm deeply interested in the intersection of 
                software engineering and artificial intelligence. I actively explore machine learning 
                applications, natural language processing, and AI-powered system design.
              </p>
            </div>

            <div className="space-y-4">
              <p className="text-lg leading-relaxed text-muted-foreground">
                When I'm not coding, you can find me writing technical articles, contributing to 
                open-source projects, or experimenting with the latest AI frameworks. I believe in 
                continuous learning and staying at the forefront of technology.
              </p>
              <p className="text-lg leading-relaxed text-muted-foreground">
                My goal is to create elegant solutions that not only solve problems but also inspire 
                and educate others in the development community.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
